============================================================================================================================================
							AR15 Spring Set by Ivan/John
============================================================================================================================================
Lots of goodies in here.  The latch spring goes under the plunger and locks the cover closed.  The 'wound' spring is the cover spring
cocked by 1/2 a turn, which is how it is/was on my uppers.  Also included is the pin that goes in the upper for the dust cover to ride on.

The retainer for the pin is in the actual model assembly file.  I didn't make it, Jacob did.