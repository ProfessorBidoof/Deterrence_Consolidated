============================================================================================================================================
							AR15 Spring Set by Ivan/John
============================================================================================================================================
This piece of work is the spring that holds the delta ring forward.

x_t versions of this part were importing as shells and with weird features.  I'm leaving it out.