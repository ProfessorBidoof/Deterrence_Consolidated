============================================================================================================================================
							AR15 Spring Set by Ivan/John
============================================================================================================================================
I thought it would be useful to have a repo of all the springs used in an AR.  I modeled the springs as non-dynamic ones, since different
modeling studios don't work with other's dynamic springs.  In the future, the group plans to work on a dynamic model.  I have done my best
to include .stp and .x_t files for each spring, in both compressed and uncompressed lengths.  This repo is fairly work in progress, we are
working on a git repo to host them one day soon.



Some springs I found mil-specs for, others I had to reverse spec from existing parts.  No springs have guessed dimensions, all are at least
somewhat accurate.  I didn't spend a whole bunch of time making flat-ends on springs that have them, V2 of the repo should include that.




DM me on twitter @IvanTheTroll12 for questions or to just say hi.  Also, hit me up if you find blatant errors in the springs, I'm human.
Some of the springs in my directory are bad/outdated, I tried to weed them out.