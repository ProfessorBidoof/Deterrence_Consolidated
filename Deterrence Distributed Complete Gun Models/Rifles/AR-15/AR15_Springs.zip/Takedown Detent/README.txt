============================================================================================================================================
							AR15 Spring Set by Ivan/John
============================================================================================================================================
Not a spring, but the detent for the takedowns.  I don't think you could print one, but with a grinder and rodstock you could get pretty
close.