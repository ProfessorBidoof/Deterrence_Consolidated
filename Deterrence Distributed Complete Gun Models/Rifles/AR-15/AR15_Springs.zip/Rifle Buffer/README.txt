============================================================================================================================================
							AR15 Spring Set by Ivan/John
============================================================================================================================================
Since rifle length >>>>>> carbine length, here's the uncompressed rifle length spring.  If ya'll need a compressed rifle length spring, hit
me up.  I'll get one in the v2 repo.