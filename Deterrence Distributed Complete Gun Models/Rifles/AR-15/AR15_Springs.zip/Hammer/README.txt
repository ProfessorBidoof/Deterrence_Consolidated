============================================================================================================================================
							AR15 Spring Set by Ivan/John
============================================================================================================================================
This spring was a PITA.  getting the angles perfect on a non-dynamic spring like this sucked.  If you use a mil-spec lower and FCG, then
this spring should fit nicely, as it would on a real setup.