============================================================================================================================================
							AR15 Spring Set by Ivan/John
============================================================================================================================================
Like with the hammer spring, this guy sucked.  It should fit it with the hammer dropped.  Keep in mind with the hammer cocked, the trigger
cocks as well on mil-spec FCGs.  This spring is not made to fit perfect with the hammer is cocked.