============================================================================================================================================
							AR15 Spring Set by Ivan/John
============================================================================================================================================
Snap ring that holds the delta ring spring in place.  The expanded one isn't perfect, but the non-expanded one is.

If you home-build the expanded snap ring you've messed up.  Make the closed one, or buy it.